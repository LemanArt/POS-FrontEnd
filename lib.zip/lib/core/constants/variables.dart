class Variables {
  static const String baseUrl = 'http://172.20.10.6:8000';
  static const String ImagebaseUrl = '$baseUrl/storage/products/';
}
