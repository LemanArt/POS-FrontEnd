import 'package:flutter/material.dart';
import '../../../core/assets/assets.gen.dart';
import '../../../core/constants/colors.dart';
import '../../order/models/order_model.dart';

import '../../../core/extensions/int_ext.dart'; // Pastikan format mata uang sudah diatur di sini

class HistoryTransactionCard extends StatelessWidget {
  final EdgeInsets padding;
  final OrderModel data;

  const HistoryTransactionCard({
    super.key,
    required this.padding,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 2.0),
      child: Padding(
        padding: padding,
        child: Column(
          children: [
            ListTile(
              leading: Assets.icons.payments.svg(),
              title: Text(data.paymentMethod),
              subtitle: Text('${data.totalQuantity} items'),
              trailing: Text(
                data.totalPrice.currencyFormatRp,
                style: const TextStyle(
                  color: AppColors.green,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            ExpansionTile(
              title: const Text('Detail Pesanan'),
              children: [
                ListTile(title: Text('Tanggal: ${data.transactionTime}')),
                ListTile(title: Text('Jumlah Item: ${data.totalQuantity}')),
                ListTile(
                    title: Text(
                        'Total Harga: ${data.totalPrice.currencyFormatRp}')),

                // Menampilkan daftar produk yang dipesan
                ...data.orders.map((orderItem) {
                  return ListTile(
                    title: Text('${orderItem.name} x ${orderItem.quantity}'),
                    subtitle:
                        Text('Rp ${orderItem.totalPrice.currencyFormatRp}'),
                  );
                }), // pastikan ini diubah ke `.toList()` untuk menghindari error
              ],
            ),
          ],
        ),
      ),
    );
  }
}
