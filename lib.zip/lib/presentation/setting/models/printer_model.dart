class PrinterModel {
  final String name;
  final int address;

  PrinterModel({
    required this.name,
    required this.address,
  });
}
